package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
    }

    //Metodo Filtro1
    public void FiltroOne(View view){

        Intent one = new Intent(this,FiltroUno.class);
        startActivity(one);
    }

    //Metodo Anterior
    public void Anterior(View view){

        Intent atras = new Intent(this,RegistroDatosUno.class);
        startActivity(atras);
    }
}
