package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class RegistroDatosUno extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_datos_uno);
    }

    //Metodo Atras
    public void Back(View view){

        Intent atras = new Intent(this,DatosRegistro.class);
        startActivity(atras);
    }

    //Metodo Siguiente
    public void Next(View view) {

        Intent siguiente = new Intent(this, CreateAccount.class);
        startActivity(siguiente);

    }
}
