package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ajustes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);
    }

    //Metodo Recompensas

    public void Recompensas(View view){
        Intent recompensas = new Intent(this,Recompensas.class);
        startActivity(recompensas);
    }

    //Metodo Actividad
    public void Menu(View view){

        Intent menu = new Intent(this,MenuPrincipal.class);
        startActivity(menu);
    }

    //Metodo ajustes
    public void Ajustes(View view){

        Intent ajustes = new Intent(this,Ajustes.class);
        startActivity(ajustes);
    }

    //Metodo ejercicios
    public void Ejercicios(View view){

        Intent ejercicios = new Intent(this,Ejercicios.class);
        startActivity(ejercicios);
    }

    //Metodo Salir

    public void Salir(View view){
        Intent salir = new Intent(this,Re.class);
        startActivity(salir);
    }
}
