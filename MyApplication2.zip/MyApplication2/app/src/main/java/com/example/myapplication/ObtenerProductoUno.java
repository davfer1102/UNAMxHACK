package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ObtenerProductoUno extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obtener_producto_uno);
    }

    //Metodo Recompensa1
    public void RecompensaUnoObtenida(View view){

        Intent recompensaunoobtenida = new Intent(this,MenuPrincipal.class);
        startActivity(recompensaunoobtenida);
    }
}
