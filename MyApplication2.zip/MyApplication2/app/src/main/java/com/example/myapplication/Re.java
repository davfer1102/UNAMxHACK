package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Re extends AppCompatActivity {

    private EditText edit_correo, edit_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_re);

        edit_correo = (EditText)findViewById(R.id.editTextCorreo);
        edit_pass = (EditText)findViewById(R.id.editTextPass);
    }

    //Metodo Ingresar cuenta
    public void LoginCuenta(View view){

        Intent logcuenta = new Intent(this,MenuPrincipal.class);
        startActivity(logcuenta);
    }

    //Metodo Validar Campos
    public void Valida(View view){

        String correo = edit_correo.getText().toString();
        String password = edit_pass.getText().toString();

        if(correo == "" || correo.length() < 15){
            Toast.makeText(this,"Correo no válido",Toast.LENGTH_LONG).show();
        } else if(password == "" || password.length() < 8){
            Toast.makeText(this,"Contraseña no válida",Toast.LENGTH_LONG).show();
        } else if(password == "" || password.length() < 8 && correo == "" || correo.length() < 15){
            Toast.makeText(this,"Campos inválidos",Toast.LENGTH_LONG).show();
        } else{
            LoginCuenta(view);
        }
    }
}
