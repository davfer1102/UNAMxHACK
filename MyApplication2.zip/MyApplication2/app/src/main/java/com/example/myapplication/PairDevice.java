package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PairDevice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_device);
    }

    //Metodo Anterior
    public void Anterior(View view){

        Intent atras = new Intent(this,FiltroDos.class);
        startActivity(atras);
    }

    //Metodo Finish
    public void FiltroTwo(View view){

        Intent dos = new Intent(this,UserChecked.class);
        startActivity(dos);
    }
}
