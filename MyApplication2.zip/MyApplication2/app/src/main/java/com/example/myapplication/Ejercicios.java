package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Ejercicios extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicios);

    }

    //Metodo Recompensas

    public void Recompensas(View view){
        Intent recompensas = new Intent(this,Recompensas.class);
        startActivity(recompensas);
    }

    //Metodo Actividad
    public void Menu(View view){

        Intent menu = new Intent(this,MenuPrincipal.class);
        startActivity(menu);
    }

    //Metodo ajustes
    public void Ajustes(View view){

        Intent ajustes = new Intent(this,Ajustes.class);
        startActivity(ajustes);
    }


}
