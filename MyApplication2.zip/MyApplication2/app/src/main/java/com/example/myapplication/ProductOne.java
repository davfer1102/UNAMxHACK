package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ProductOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_one);
    }

    //Metodo Recompensa1
    public void RecompensaUnoObtener(View view){

        Intent recompensaunoobtener = new Intent(this,ObtenerProductoUno.class);
        startActivity(recompensaunoobtener);
    }

    //Metodo Actividad
    public void Menu(View view){

        Intent menu = new Intent(this,MenuPrincipal.class);
        startActivity(menu);
    }

    //Metodo ajustes
    public void Ajustes(View view){

        Intent ajustes = new Intent(this,Ajustes.class);
        startActivity(ajustes);
    }

    //Metodo Recompensas
    public void Recompensas(View view){

        Intent recompensas = new Intent(this,Recompensas.class);
        startActivity(recompensas);
    }
}
