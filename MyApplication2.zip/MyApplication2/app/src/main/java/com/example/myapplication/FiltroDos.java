package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class FiltroDos extends AppCompatActivity {

    private RadioButton rb_uno, rb_dos, rb_tres, rb_cuatro, rb_cinco, rb_seis;
    String respuestados = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtro_dos);

        rb_uno = (RadioButton)findViewById(R.id.radioUno);
        rb_dos = (RadioButton)findViewById(R.id.radioDos);
        rb_tres = (RadioButton)findViewById(R.id.radioTres);
        rb_cuatro = (RadioButton)findViewById(R.id.radioCuatro);
        rb_cinco = (RadioButton)findViewById(R.id.radioCinco);
        rb_seis = (RadioButton)findViewById(R.id.radioSeis);
    }

    //Metodo Anterior
    public void Anterior(View view){

        Intent atras = new Intent(this,FiltroUno.class);
        startActivity(atras);
    }

    //Metodo Siguiente
    public void Siguiente(View view){

        Intent delante = new Intent(this,PairDevice.class);
        startActivity(delante);
        AnalisisDos(view);
        delante.putExtra("datodos",respuestados);
    }

    //Metodo AnalisisDos
    public void AnalisisDos(View view){

        if(rb_uno.isChecked() == true){
            respuestados = "uno";
        }else if(rb_dos.isChecked() == true){
            respuestados = "dos";
        }else if(rb_tres.isChecked() == true){
            respuestados = "tres";
        }else if(rb_cuatro.isChecked() == true){
            respuestados = "cuatro";
        }else if(rb_cinco.isChecked() == true){
            respuestados = "cinco";
        }else if(rb_seis.isChecked() == true){
            respuestados = "seis";
        }
    }
}
