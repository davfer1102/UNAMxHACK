package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MenuPrincipal extends AppCompatActivity {

    private TextView tv_meta;

    String dato = "";
    String datodos = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        tv_meta = (TextView)findViewById(R.id.textMeta);

        dato = getIntent().getStringExtra("dato");
        datodos = getIntent().getStringExtra("datodos");

    }

    //Metodo ejercicios
    public void Ejercicios(View view){

        Intent ejercicios = new Intent(this,Ejercicios.class);
        startActivity(ejercicios);
    }

    //Metodo Actividad
    public void Menu(View view){

        Intent menu = new Intent(this,MenuPrincipal.class);
        startActivity(menu);
    }

    //Metodo ajustes
    public void Ajustes(View view){

        Intent ajustes = new Intent(this,Ajustes.class);
        startActivity(ajustes);
    }

    //Metodo Recompensas
    public void Recompensas(View view){

        Intent recompensas = new Intent(this,Recompensas.class);
        startActivity(recompensas);
    }

    //Metodo cambiar textos
    public void CambiarTextos(View view){


        if(dato == "nula" && datodos == "uno"){
            tv_meta.setText("Tu meta diaria de 2500 pasos mas ejercicios de estiramiento");
        }

    }
}
