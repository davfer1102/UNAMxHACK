package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class FiltroUno extends AppCompatActivity {

    private RadioButton rb_uno, rb_dos, rb_tres, rb_cuatro, rb_cinco, rb_seis;
    String respuesta = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtro_uno);

        rb_uno = (RadioButton)findViewById(R.id.radioUno);
        rb_dos = (RadioButton)findViewById(R.id.radioDos);
        rb_tres = (RadioButton)findViewById(R.id.radioTres);
        rb_cuatro = (RadioButton)findViewById(R.id.radioCuatro);
        rb_cinco = (RadioButton)findViewById(R.id.radioCinco);
        rb_seis = (RadioButton)findViewById(R.id.radioSeis);

    }

    //Metodo Anterior
    public void Anterior(View view){

        Intent atras = new Intent(this,CreateAccount.class);
        startActivity(atras);
    }

    //Metodo FiltroDos
    public void FiltroTwo(View view){

        Intent dos = new Intent(this,FiltroDos.class);
        startActivity(dos);
        AnalisisUno(view);
        dos.putExtra("dato",respuesta);

    }

    //Metodo Analisis
    public void AnalisisUno(View view){

        if(rb_uno.isChecked() == true){
            respuesta = "nula";
        }else if(rb_dos.isChecked() == true){
            respuesta = "baja";
        }else if(rb_tres.isChecked() == true){
            respuesta = "media";
        }else if(rb_cuatro.isChecked() == true){
            respuesta = "alta";
        }
    }
}
