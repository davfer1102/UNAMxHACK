package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DatosRegistro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_registro);
    }

    //Metodo Atras
        public void Back(View view){

            Intent atras = new Intent(this,MainActivity.class);
            startActivity(atras);
        }

        //Metodo Siguiente
        public void Next(View view) {

            Intent siguiente = new Intent(this, RegistroDatosUno.class);
            startActivity(siguiente);

    }
}
